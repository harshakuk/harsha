package com.ul.project.interceptor;

public interface ILogger {
	public void logging();
}
